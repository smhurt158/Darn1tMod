## 0.1.1

- Made Speed Nerf visible

## 0.1.0

- First Thunderstore Prerelease